package StudentApplication.SpringJPAHibernate;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringJpaHibernateApplicationTests {

	@Test
	void contextLoads() {
	}

}
